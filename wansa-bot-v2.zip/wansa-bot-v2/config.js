module.exports = {
    prefix: "-",
    color: "#7B2CBF"
};
